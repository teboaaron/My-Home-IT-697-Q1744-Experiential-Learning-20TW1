import simplejson

# a Python object (dict):
x = {
  "name": "John",
  "age": 30,
  "city": "New York"
}

# convert into JSON:
y = simplejson.dumps(x)

# the result is a JSON string:
print(y)