import paho.mqtt.client as mqtt
local_client = mqtt.Client()
local_client.connect("localhost")
local_client.loop_start()

local_client.publish("spaceballs", "Hi there, Spaceballs was a good movie")

raw_input("hit any key to leave the galaxy")
