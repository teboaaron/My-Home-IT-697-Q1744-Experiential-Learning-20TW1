import paho.mqtt.client as mqtt
local_client = mqtt.Client()
local_client.connect("localhost")
local_client.loop_start()

local_client.publish("tebo/aaron", "Hi there, Aaron Tebo you modified this code!")

raw_input("Aaron Sent, type enter to continue")
